from django.apps import AppConfig


class ShopeazyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shopeazy'
