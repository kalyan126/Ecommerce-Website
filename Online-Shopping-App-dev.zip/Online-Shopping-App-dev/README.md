ShopEazy Shopping Portal

[Figma Prototype](https://www.figma.com/file/Y7GhMGNATywEDXP6QprSuZ/Full-Stack-Prototype?node-id=36%3A67&t=CHzvisYdyKjV4bjJ-0)

[Business Requirement Document](https://uottawa-my.sharepoint.com/personal/adhil030_uottawa_ca/_layouts/15/guestaccess.aspx?docid=0e9a250eb1b8b457393c59a89995d644d&authkey=AeNSICmuGnTLWo_hJowVQ6E&e=oxqfmb)

[Software Requirement Specifications](https://uottawa-my.sharepoint.com/personal/adhil030_uottawa_ca/_layouts/15/guestaccess.aspx?docid=0a193ef5a141045b79670974a624ecaa1&authkey=AQ46l3QYCfPrXsylgs5nGts&e=NGNrRw)

Project Report 
[GNG 5300_Group Project Report.docx](https://github.com/GurjotSinghArora/Online-Shopping-App/files/10249459/GNG.5300_Group.Project.Report.docx)
